These are the additional files for ECheck V4 and above in English.

The are are the following files:

  - buildings.txt
  - commands.txt
  - directions.txt
  - help.txt
  - herbs.txt
  - items.txt
  - messages.txt
  - options.txt
  - params.txt
  - potions.txt
  - races.txt
  - ships.txt
  - skills.txt
  - spells.txt

Each of these files contains the texts for one "aspect". You can combine one
ore more parts into the file

  - tokens.txt

if you proceed them by special keywords. You can obtain the list of keywords
by using "echeck -hk".

Further instructions are inside the files.

English translation of the files: Alexander Klauer.

For DOS (using 8.3-filenames) you could either use

  - builds.txt		instead of buildings.txt
  - directs.txt		instead of directions.txt

See "echeck -hf" for a complete list of filenames.

	Faroul	(echeck@faroul.de)

