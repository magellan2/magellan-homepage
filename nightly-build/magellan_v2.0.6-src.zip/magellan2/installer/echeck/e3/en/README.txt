These are the additonal files for ECheck V4 and above in english.

The are are the following files:

  - buildings.txt
  - commands.txt
  - directions.txt
  - help.txt
  - herbs.txt
  - items.txt
  - messages.txt
  - options.txt
  - parameters.txt
  - potions.txt
  - races.txt
  - ships.txt
  - skills.txt
  - spells.txt

Each of these files contains the texts for one "aspect". You can combine one
ore more parts into the file

  - tokens.txt

if you preceed them by special keywords. You can obtain the list of keywords
by using "echeck -hk".

Further instructions are inside the files.

English translation of the files: Alexander Klauer.

See "echeck -hf" for a complete list of filenames.

	Faroul	(echeck@faroul.de)

