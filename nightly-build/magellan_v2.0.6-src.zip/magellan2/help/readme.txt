The magellan help files should be formatted with HTML Tidy (see http://www.w3.org/ or 
http://eclipsetidy.sourceforge.net/index.php) using the "Indent block-level tags = auto" option. 
The eressea help files should not be formatted as they are taken directly from the official Eressea
help.