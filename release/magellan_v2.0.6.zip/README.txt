Welcome to Magellan!

Magellan is a full-featured client tool for the play-by-e-mail
game Eressea. It displays a map of your part of the Eressea
world, supports you in writing orders, performs many complex
calculations for you and is available completely in English.

Magellan is only one among many other client programs for 
Eressea and is in no way related to the developers of Eressea.
To relieve them of unnecessary work please contact the Magellan
Community in case you have any questions or problems.

---

Unless otherwise indicated, all files in this distribution are
provided to you under the terms and conditions of the GNU GPL
License Version 2.0. A copy of this license is provided in
COPYING.

Exceptions from the GNU GPL  are notified in the source files
itself or written down in a seperate file (e.g. 
src/release/lib/jflap.LICENSE.txt).

If you are not satisfied that EVERYTHING is under the GNU GPL 
License you should not use Magellan.
