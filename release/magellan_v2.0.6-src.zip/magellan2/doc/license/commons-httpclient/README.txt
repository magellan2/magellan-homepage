Jakarta HttpClient
===========================
Welcome to the HttpClient component of the Jakarta HttpComponents project.

Visit us online at
   http://jakarta.apache.org/httpcomponents/index.html
for more information.

Visit
   http://jakarta.apache.org/httpcomponents/status.html
for the status of the project.
