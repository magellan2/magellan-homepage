This folder contains the echeck program. This is the release 4.3.2
of echeck. Please refer to <http://echeck.faroul.de/> for more
informations about this program.